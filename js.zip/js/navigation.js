(function($) {

	// DOM ready
	$(function() {
		
		// Append the mobile icon nav
		$('.nav').append($('<div class="nav-mobile"></div>'));
		// Append the mobile icon menu
		//$('.nav').append($('<div class="nav-menu"></div>'));
		
		// Add a <span> to every .nav-item that has a <ul> inside
		$('.nav-item').has('ul').prepend('<span class="nav-click"><i class="nav-arrow"></i></span>');
		
		// Click to reveal the nav
		$('.nav-mobile').click(function(){
			$('.nav-list').toggle();
		});
		
		$('.nav-item').mouseenter(function(e) {
			$(this).toggleClass('active-a');
			//$(this).children('.nav-submenu').slideToggle(500).addClass('slided');
		});
		$('.nav-item').mouseleave(function(e) {
			$(this).toggleClass('active-a');
			//$(this).children('.nav-submenu').slideToggle(500).addClass('slided');
		});
		
	
		// Dynamic binding to on 'click'
		$('.nav-list').on('click', '.nav-click', function(){
			// Toggle the nested nav
			$(this).siblings('.nav-submenu').toggle();
			$(this).siblings('.navServiceMenu').toggle();
			
			// Toggle the arrow using CSS3 transforms
			$(this).children('.nav-arrow').toggleClass('nav-rotate');
			
		});
	    
	});
	
})(jQuery);