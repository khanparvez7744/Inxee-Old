$(document).ready(function() {			
	
	if($('#enquiryvalidate').length)
		{
			$('#enquiryvalidate').formValidation({
        message: 'This value is not valid',       
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
						name: {
              //  row: '.col-md-7',
                validators: {
                    notEmpty: {
                        message: 'Name is required'
                    }
                }
            },
						emailId: {
                validators: {
                    notEmpty: {
                        message: 'The email address is required'
                    },
                    emailAddress: {
                        message: 'The input is not a valid email address'
                    }
                }
            }, 
            contactno: {              
                validators: {
                    notEmpty: {
                        message: 'Contact No. is required'
                    }
                }
            },         
            query: {
                validators: {
                    notEmpty: {
                        message: 'Query is required'
                    }
                }
            }          
        }
			});
			
		}	
			
	if($('#defaultForm').length)
		{
			$('#defaultForm').formValidation({
        message: 'This value is not valid',       
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
						
						emailId: {
                validators: {
                    notEmpty: {
                        message: 'The email address is required'
                    },
                    emailAddress: {
                        message: 'The input is not a valid email address'
                    }
                }
            },            
            mailaddress: {
                //row: '.col-md-7',
                validators: {
                    notEmpty: {
                        message: 'Mailing Address is required'
                    }
                }
            },
            mobile: {
               // row: '.col-md-7',
                validators: {
                    notEmpty: {
                        message: 'Mobile is required'
                    }
                }
            },
            designation: {
               // row: '.col-md-7',
                validators: {
                    notEmpty: {
                        message: 'Designation is required'
                    }
                }
            },
            prodName: {
              //  row: '.col-md-7',
                validators: {
                    notEmpty: {
                        message: 'Product Name is required'
                    }
                }
            },            
            prodDesc: {
                validators: {
                    notEmpty: {
                        message: 'Product Description is required'
                    }
                }
            },
            tdomain: {
               // row: '.col-md-7',
                validators: {
                    notEmpty: {
                        message: 'Target Domains is required'
                    }
                }
            },
            servicearea: {
             //   row: '.col-md-7',
                validators: {
                    notEmpty: {
                        message: 'Service Area is required'
                    }
                }
            },
            quotationreq: {
             //   row: '.col-md-7',
                validators: {
                    notEmpty: {
                        message: 'Quotation requested is required'
                    }
                }
            }           
        }
			});
		}
	
	
		
});
